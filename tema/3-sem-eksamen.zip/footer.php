    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Killevippen Vuggestue og Børnehave,   Blangstedgårds Allé 70,   5220 Odense SØ.    Tlf. 23 98 31 75.    Mail: mail@killevippen.dk</p>
      </div>
      <!-- /.container -->
    </footer>
    <?php wp_footer(); ?>

    <!-- Bootstrap core JavaScript -->
    <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/core.js"></script>
    

  </body>

</html>